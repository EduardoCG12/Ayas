package com.example.ayashome;

public class Values {

    public static final String LOG_TAG = "tag_ayas";

}
